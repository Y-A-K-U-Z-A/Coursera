package m;

import java.util.Scanner;

public class Welcoming {
private final Scanner sc = new Scanner(System.in);
private String[] args;

    public void printout(){
        System.out.println("Welcome to Coursera project!");
        System.out.println("Please enter PIN's of student (optional)");
        String input = sc.nextLine();
        System.out.println("Enter the required minimum needed credit.");
        String credits = sc.nextLine();
        System.out.println("Enter the start date and end date separated with comma (,). (year-month-date)");
        String dateTime = sc.nextLine();
        this.args = new String[3];
        this.args[0] = input;
        this.args[1] = credits;
        this.args[2] = dateTime;
    }

    public String[] getArgs(){
        return this.args;
    }
}
