package m;

import reading.Engine;

public class Main {
    public static void main(String[] args) {
        Welcoming welcoming = new Welcoming();
        welcoming.printout();

        Engine engine = new Engine(welcoming.getArgs());
        engine.run();
    }
    //9412011005
//2020-03-16, 2020-04-10
//Deals_With1Devil
}
