package reading;

import processing.Process;

import java.sql.SQLException;

public class Engine implements Runnable{
    private Reader reader;
    private String[] args;
    private Process process;

    public Engine(String[] args){
        this.args = args;
        reader = new Reader();
        reader.read(this.args);
        process = new Process(reader.getPins(), reader.getCredits(), reader.getStartDate(), reader.getEndDate());
    }
    @Override
    public void run() {
        try {
            process.getStudentInfo();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //todo
    }
}
