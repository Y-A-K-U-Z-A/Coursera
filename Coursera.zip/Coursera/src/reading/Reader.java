package reading;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Reader {
    private final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private int credits;
    private String[] pins;
    private String startDate;
    private String endDate;

    public Reader() {
    }

    public void read(String[] args){
        if (args[0] == null || args[0].trim()== ""){
            //no pins
            String[] pins = null;
        }else {
            //pins
            this.pins = args[0].split(",\\s+");
        }
        credits = Integer.parseInt(args[1]);
        String[] dates = args[2].split(",\\s+");
        this.startDate = dates[0];
        this.endDate = dates[1];
    }

    public int getCredits() {
        return credits;
    }

    public String[] getPins() {
        return pins;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }
}
