package processing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Connector {
    private Connection connection;
    private Properties properties;

    public Connector(String userName, String password) throws SQLException {
        properties = new Properties();
        properties.setProperty("user", userName);
        properties.setProperty("password", password);
        this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/coursera", properties);
    }
    public Connection getConnection(){
        return this.connection;
    }
}
