package processing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class Process {
    private String[] pins;
    private int credits;
    private String startDate;
    private String endDate;
    private List<String> information;
    private Connection con;
    private final Scanner sc = new Scanner(System.in);

    public Process(String[] pins, int credits, String startDate, String endDate)
    {
        this.pins = new String[pins.length];
        this.pins = pins;
        this.credits = credits;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public List<String> getStudentInfo() throws SQLException {
        getConnection();
        StringBuilder sb = new StringBuilder();
        if (pins != null){
            //търся по пин на студента
            for (String pin : pins) {
                PreparedStatement ps = this.con.prepareStatement("select concat(s.first_name, ' ', s.last_name) from students as s where pin = ?");
                String studentName = "";
                ps.setString(1,pin);
                ps.execute();
                ResultSet rs = ps.getResultSet();
                rs.next();
                studentName = rs.getString(1);
                sb.append("Student name: ");
                sb.append(studentName).append(System.lineSeparator());
                sb.append(getCourseInfo(pin)).append(System.lineSeparator());

            }
        }else {
            //аll students with enough credit should be included
            String str = getCoursesInfo();
        }
        System.out.println(sb.toString());
        return null;
    }

    private String getCoursesInfo() throws SQLException {
        PreparedStatement ps = this.con.prepareStatement("select s.first_name, c.name,c.total_time, credit, concat(i.first_name, ' ', i.last_name) as instructor_name  from courses as c \n" +
                "join students_courses_xref as sc\n" +
                "on sc.course_id = c.id\n" +
                "join students as s \n" +
                "on s.pin = sc.student_pin\n" +
                "join instructors as i\n" +
                "on c.instructor_id = i.id\n");
        ps.execute();
        ResultSet rs = ps.getResultSet();
        int total = 0;
        List<String[]> courseInfo = new ArrayList<>();

        while(rs.next()){
            courseInfo.add(new String[]{rs.getString(2), String.valueOf(rs.getInt(3)),
                    String.valueOf(rs.getInt(4)), rs.getString(5)});
            total += rs.getInt(4);
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Total credit: ").append(total).append(System.lineSeparator());
        for (String[] s : courseInfo) {
            sb.append("Course name, time, credit, instructor: ").append(System.lineSeparator());
            sb.append(String.format("%s \t%s \t%s \t%s",  s[0], s[1], s[2], s[3])).append(System.lineSeparator());
        }

        return sb.toString();

    }

    private String getCourseInfo(String pin) throws SQLException {
        PreparedStatement ps = this.con.prepareStatement("select s.first_name, c.name,c.total_time, credit, concat(i.first_name, ' ', i.last_name) as instructor_name  from courses as c \n" +
                "join students_courses_xref as sc\n" +
                "on sc.course_id = c.id\n" +
                "join students as s \n" +
                "on s.pin = sc.student_pin\n" +
                "join instructors as i\n" +
                "on c.instructor_id = i.id\n" +
                "where s.pin = ?;");
        ps.setString(1,pin);
        ps.execute();
        ResultSet rs = ps.getResultSet();
        int total = 0;
        List<String[]> courseInfo = new ArrayList<>();

        while(rs.next()){
            courseInfo.add(new String[]{rs.getString(2), String.valueOf(rs.getInt(3)),
                String.valueOf(rs.getInt(4)), rs.getString(5)});
            total += rs.getInt(4);
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Total credit: ").append(total).append(System.lineSeparator());
        for (String[] s : courseInfo) {
            sb.append("Course name, time, credit, instructor: ").append(System.lineSeparator());
            sb.append(String.format("%s \t%s \t%s \t%s",  s[0], s[1], s[2], s[3])).append(System.lineSeparator());
        }

        return sb.toString();
    }

    private void getConnection() throws SQLException {
        System.out.println("Enter database server username:");
        String username = sc.nextLine();
        System.out.println("Enter database server password:");
        String password = sc.nextLine();
        Connector connector = new Connector(username, password);
        this.con = connector.getConnection();
    }


}
